# __init__.py
from .models import Models
from .resnet import ResNet

