# ERAV2-Architecture
ERAV2 course models
